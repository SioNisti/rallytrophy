Control Settings Fix for Rally Trophy on Windows Vista+
=======================================================

Being released back in 2001, Rally Trophy has suffered from a compatibility
issue with Windows releases since Vista, making it impossible to configure key
bindings and game controllers on these newer systems. The problem is simple:
Rally Trophy uses a controller settings dialog that is provided by DirectInput
(namely [`IDirectInput8::ConfigureDevices`][msdn]). However, this method was
deprecated with the release of Windows Vista and the dialog itself was removed
from Vista and any subsequent Windows releases. Because of that, configuring
controls for the game became pretty much impossible on these systems, outside of
workarounds like using an XP system to set up controls or even changing the
DirectInput configuration files manually. This fix solves this problem by
providing a re-implementation of the controls dialog (originally based on code
from [the Wine project][winehq]).


Installation
------------

Simply drop the `dinput8.dll` and `dimap.dll` files into your Rally Trophy
installation directory (next to `RallyTrophy.exe`). In addition, you'll need to
install the *Microsoft Visual C++ 2012 x86 Redistributable* (if you don't have
it) using the `vcredist_x86.exe` executable.


Support for other games
-----------------------

While this patch was originally developed for Rally Trophy, it works for other
games that suffer from this particular bug. For any of these games, install the
patch as described above, but drop the files into the game's installation
directory (next to the game's main executable file). These further games were
tested and are known to work (except where noted otherwise):
* Juiced (2005, Juice Games/THQ) - crashes have been reported (but settings are
  kept); also works with the free demo
* Rally Championship Xtreme (2001, Warthog/SCi) - should work with no further
  issues


Changelog
---------

* 1.4 (2014-08-21)
  - removed ATL dependency, building with VS Express should actually work now
  - explicitly support more games (as a corollary, any Rally-Trophy-specific
    hacks are now only enabled when being loaded from `RallyTrophy.exe`)
  - switching devices doesn't discard changes; instead, changes on all device
    pages are saved when confirming the dialog (a side effect seems to have been
    that all controllers are active all the time in Rally Trophy, which is nice)
  - button numbering should start at 1 now for most (if not all) controllers
  - listed actions are now filtered by their names, which should eliminate
    duplicate actions in all games
* 1.3 (2014-06-03)
  - fixed yet another issue with "Show Assigned First"
* 1.2 (2014-06-03)
  - add a shortcut to open the device's control panel to the config dialog
  - the config dialog now uses the Windows XP+ interface visual styles
  - fixed the disappearing mouse cursor when using the widescreen fix's windowed
    mode
  - the assignable "Pause" action now works on controllers (note that that was
    an original Rally Trophy bug)
  - fixed a config issue when using the "Show Assigned First" option
* 1.1 (2014-05-16)
  - add an extra confirmation dialog when changes might be silently lost
  - add required `dimap.dll` file (this particular copy was taken from an
    [August 2006 DirectX installer][dxsetup])
* original release (2014-01-29)
  - initial release


Building from source
--------------------

Use Visual Studio 2012, Express should work. Other versions might require some
legwork to convert the project files. To debug the patch with a game, set the
output directory in the project settings of the appropriate debug configuration
to your specific installation directory, then just start debugging in VS to
launch the game in the debugger.

To add a debug configuration for a new game (basic steps):
* in the Configuration Manager, create a new build configuration for the
  `rt-dinput-wrapper` project, copying the settings from another debug
  configuration
* on the *General* page, set the output directory to the game's installation
  directory (the directory with the game's main executable file)
* on the *Debugging* page, update the *Command* field with the name of the
  game's main executable file


Legal
-----

This library (`dinput8.dll`) is Copyright (c) 2014 Felix Krull.

This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free
Software Foundation; either version 2.1 of the License, or (at your option) any
later version.

This library is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this library.  If not, see <http://www.gnu.org/licenses/>.

This library includes code from [the Wine project][winehq] which is
Copyright (c) 1993-2014 the Wine project authors.

*Microsoft Visual C++ 2012 x86 Redistributable* is a Microsoft product and is
included according to the "Distributable Code" terms of the Microsoft Software
License Terms for Visual Studio 2012.

`dimap.dll` is a part of Microsoft DirectX for Windows 9x/ME and was taken from
the [August 2006 DirectX Redistributable][dxsetup].


[msdn]: http://msdn.microsoft.com/en-us/library/windows/desktop/microsoft.directx_sdk.idirectinput8.idirectinput8.configuredevices%28v=vs.85%29.aspx
[winehq]: http://winehq.org
[dxsetup]: http://www.microsoft.com/en-us/download/details.aspx?id=20265
