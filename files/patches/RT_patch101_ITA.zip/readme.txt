Rally Trophy v1.01: Italian version
------------------
Note: Make sure you install the patch into the directory your copy of Rally Trophy is in! 
Example: C:\Program Files\Jowood\Rally Trophy\



BUGFIXES:

- Input: Deadzone problem on pedals
- Input: Bug in combined axis bone
- Input: "Steering bug"
- DLL: Minor mipmap generation bug
- Some stage infos contained wrong information
- Intro video volume was too high	
- Minor translation bugs
- Multiplayer: Broken (interior) windows were not broken after ghostmode
- Alternative seats bug in single rally mode
- Broken drive lights were repaired in replay (expert level)
- Ford escort was intermediate level car in multiplayer mode
- Minor cosmetic changes	
- other minor fixes
	


NEW FEATURES:

GENERAL:

- Improved physics
- Improved performance and reduced need of system resources
- Some cosmetic changes
- Average & top speed of stage record is shown in stage infos
- More nationalities (64 now)

CONTROLS:

- Input.ini file in the rallytrophy\data\settings folder has descriptions for each parameter. Use only if you really need to customize your controller values(and backup the original input.ini)!

REPLAY:

- Possibility to save & view replays (saving is done via record button in replay controls, loading in replay menu)
- Replay controls include generic VCR control scheme (note that rewind restarts replay) and slow-motion. 
- In multiplayer replays you can switch to another player in replay with the assigned gear shifting buttons / keys. You can also do the same while waiting for other players to finish the stage	behind you.

MENU:

- Possibility to disable co-driver comments (in Sound Options)
- Possibility to disable visual pace notes (in Race Options)
- Possibility to disable lens flares (Graphics menu / Effect detail: disabled)

HIGHSCORES:

- Encrypted highscores for extra safety against cheating
- Highscores are saved when updated (not only when game exits)
- More complete highscores (ability to view per rally, race mode, car and individual stage)
- Highscores include multiplayer opponents as well

MULTIPLAYING:

- Cheat protection for online gaming: If the game detects changed physics files, it will exit. Modified files can be used in singleplayer mode but highscores aren't saved.
- Extra commandline parameters (multiplayer options, not mandatory to use):

	+host {port}
	+connect{:port}
	+name"player name"
	+hostname"My game room"
	+game"Rally Russia"	
	+ghostmode [0,1]
	+damage [0,1]
	+cars [novice, intermediate, expert, all]

	Example: RallyTrophy.exe +host +name "Spikey" +hostname "My Gameroom" +game "Rally Russia" +damage 1 +cars all
